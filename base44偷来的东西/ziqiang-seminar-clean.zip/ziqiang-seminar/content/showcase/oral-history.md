---
title: 城市记忆的口述史方法：以北京胡同为例
slug: oral-history
type: 报告
author: 苏婉清
identity: 社会学系 2023 级硕士生
date: 2026-05-18
description: 通过口述史方法记录北京胡同居民的日常记忆，探讨城市更新背景下微观历史保存的伦理与方法论问题。
file: /assets/files/submission-guidelines.pdf
---
