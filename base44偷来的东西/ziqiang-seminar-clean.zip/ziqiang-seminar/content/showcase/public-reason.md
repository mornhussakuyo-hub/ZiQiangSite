---
title: 公共理性与数字时代的信息秩序
slug: public-reason
type: 论文
author: 林知远
identity: 哲学系 2024 级博士生
date: 2026-05-18
description: 本文考察数字媒介对公共理性的塑造作用，主张在信息过载条件下重建学术共同体的论证规范与知识权威。
file: /assets/files/submission-guidelines.pdf
---
