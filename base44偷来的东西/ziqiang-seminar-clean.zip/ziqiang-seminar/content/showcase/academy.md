---
title: 宋代书院制度与现代大学精神
slug: academy
type: 论文
author: 何承泽
identity: 历史系 2022 级博士生
date: 2026-05-18
description: 梳理宋代书院的组织形态与教学理念，反思其与现代大学自治、通识教育传统之间的历史延续与断裂。
file: /assets/files/submission-guidelines.pdf
---
