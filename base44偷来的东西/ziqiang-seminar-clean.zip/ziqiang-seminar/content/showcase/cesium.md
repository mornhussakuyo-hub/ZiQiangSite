---
title: 铯元素核反应截面的实验测定
slug: cesium
type: 项目
author: 周明远 等
identity: 物理学院本科生课题组
date: 2026-05-18
description: 利用加速器实验测定铯元素核反应截面数据，为相关天体物理模型提供新的实验约束与参数修正依据。
file: /assets/files/submission-guidelines.pdf
---
