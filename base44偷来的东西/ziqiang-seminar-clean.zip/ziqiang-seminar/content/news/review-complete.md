---
title: 组委会完成首轮论文评议工作
slug: review-complete
category: 动态
date: 2026-06-28
author: 学术评议组
source: 自强学术研讨会组委会
description: 本届组委会已完成首轮来稿评议，共收到投稿 187 篇，入选分论坛报告 42 篇，结果将于两周内通知作者。
featured: false
cover: /assets/images/library-article.webp
---
本届组委会已完成首轮来稿评议，共收到投稿 187 篇，入选分论坛报告 42 篇。

## 评议原则

评议重点包括问题意识、论证质量、材料可靠性与表达清晰度。评议组将于两周内向作者发送结果与修改建议。
