---
title: 第十一届自强学术研讨会
slug: 2025-autumn
category: 往期回顾
date: 2025-11-02
author: 自强学术研讨会组委会
source: 自强学术促进会
description: 第十一届研讨会以“技术、社会与人的尺度”为主题，完成三场报告与一场跨学科圆桌。
cover: /assets/images/library-article.webp
---
第十一届自强学术研讨会以“技术、社会与人的尺度”为主题，讨论技术变迁中的制度、伦理与教育问题。
