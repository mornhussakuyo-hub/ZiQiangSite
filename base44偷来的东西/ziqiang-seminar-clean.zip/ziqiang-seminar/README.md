# 自强学术研讨会网站

这是根据组委会需求说明与 Base44 页面预览清洗、重构得到的静态网站项目。

项目没有 Base44 SDK、认证、数据库、埋点、Stripe、Monaco 或其他平台运行时依赖。构建脚本只使用 Python 标准库；浏览器端只有一份原生 JavaScript，用于移动菜单、滚动导航和横向日程浏览。

## 快速开始

```bash
python3 scripts/build.py
python3 scripts/check_site.py
python3 -m http.server 4173 -d dist
```

然后访问：

```text
http://localhost:4173
```

也可以使用 npm 作为统一命令入口（不需要 `npm install`）：

```bash
npm run build
npm run check
npm run serve
```

## 目录

```text
content/                 Markdown 内容
  news/                  新闻与预热
  archive/               往期回顾
  showcase/              精彩展示卡片
data/                    站点、日程、成员、赞助方数据
src/assets/              CSS、JavaScript、图片和下载文件
scripts/build.py         零依赖静态站生成器
scripts/check_site.py    内部链接与基础页面检查
dist/                    构建产物，可直接部署
docs/                    需求书、参考图和交接说明
```

## 已实现页面

- `/` 首页
- `/news/` News 列表
- `/news/[slug]/` News 详情
- `/archive/` 往期回顾
- `/archive/[slug]/` 往期详情
- `/committee/` 组委会成员
- `/showcase/` 精彩展示
- `/contact/` 联系我们
- `/magazine/` Magazine 预留页
- `/404.html` 静态 404 页面

## 修改内容

### 修改站点名称、邮箱、主旨等

编辑：

```text
data/site.json
```

### 新增 News

复制 `content/news/` 中任意 Markdown 文件，修改 front matter 和正文，再重新构建。

### 新增精彩展示

在 `content/showcase/` 中新增 Markdown 文件。资料文件放入：

```text
src/assets/files/
```

### 修改组委会和赞助方

编辑：

```text
data/members.json
data/sponsors.json
```

## 部署

`dist/` 是最终静态文件目录，可部署到：

- Cloudflare Pages
- GitHub Pages
- Netlify
- 学院服务器 / Nginx

Cloudflare Pages 的构建命令可填写：

```text
python3 scripts/build.py
```

输出目录：

```text
dist
```

## 上线前必须替换

当前内容仍含示例占位：

- 真实 Logo、favicon
- Global Slogan 最终文案
- 组委会姓名、照片、职责和个人链接
- 正式邮箱、手机号、两类联系对接人
- 赞助方名称、Logo 和外链
- 正式新闻、往期内容和展示材料
- 示例 PDF
- 背景图片与文章头图

现有图书馆图片来自 Base44 生成页面的静态资源，原始授权信息没有出现在 MHTML 中。正式上线前应由组委会确认可用性，或替换为明确授权的校园/活动摄影。

## 交接

请先阅读：

```text
CODEX_HANDOFF.md
```
