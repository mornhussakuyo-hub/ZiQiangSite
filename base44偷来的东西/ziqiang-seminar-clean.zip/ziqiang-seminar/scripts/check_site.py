#!/usr/bin/env python3
from __future__ import annotations
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DIST = ROOT / "dist"
errors: list[str] = []
html_files = list(DIST.rglob("*.html"))

for path in html_files:
    text = path.read_text(encoding="utf-8")
    for required in ("<title>", 'name="description"'):
        if required not in text:
            errors.append(f"{path.relative_to(DIST)} missing {required}")
    if not re.search(r"id=['\"]main['\"]", text):
        errors.append(f"{path.relative_to(DIST)} missing main landmark")
    for match in re.finditer(r'href="(/[^"]*)"', text):
        url = match.group(1).split("#", 1)[0].split("?", 1)[0]
        if not url or url.startswith("//"):
            continue
        candidate = DIST / url.lstrip("/")
        if url.endswith("/"):
            candidate = candidate / "index.html"
        elif candidate.suffix == "":
            candidate = candidate / "index.html"
        if not candidate.exists():
            errors.append(f"{path.relative_to(DIST)} broken link: {url}")
    for match in re.finditer(r'src="(/[^"]*)"', text):
        candidate = DIST / match.group(1).lstrip("/")
        if not candidate.exists():
            errors.append(f"{path.relative_to(DIST)} missing asset: {match.group(1)}")

if errors:
    print("Site check failed:")
    for error in sorted(set(errors)):
        print(" -", error)
    raise SystemExit(1)
print(f"Site check passed: {len(html_files)} HTML files checked.")
