#!/usr/bin/env python3
"""Zero-dependency static-site build for the Ziqiang Academic Seminar website."""
from __future__ import annotations

import html
import json
import re
import shutil
from dataclasses import dataclass
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
DIST = ROOT / "dist"


@dataclass
class ContentItem:
    meta: dict[str, Any]
    body: str
    source: Path


def load_json(name: str) -> Any:
    return json.loads((ROOT / "data" / name).read_text(encoding="utf-8"))


def parse_scalar(value: str) -> Any:
    value = value.strip()
    if value.lower() in {"true", "false"}:
        return value.lower() == "true"
    if (value.startswith('"') and value.endswith('"')) or (value.startswith("'") and value.endswith("'")):
        return value[1:-1]
    return value


def parse_content(path: Path) -> ContentItem:
    text = path.read_text(encoding="utf-8").replace("\r\n", "\n")
    if not text.startswith("---\n"):
        return ContentItem({}, text, path)
    _, raw_meta, body = text.split("---\n", 2)
    meta: dict[str, Any] = {}
    for line in raw_meta.splitlines():
        if not line.strip() or line.lstrip().startswith("#"):
            continue
        key, sep, value = line.partition(":")
        if sep:
            meta[key.strip()] = parse_scalar(value)
    return ContentItem(meta, body.strip(), path)


def load_collection(name: str) -> list[ContentItem]:
    items = [parse_content(p) for p in sorted((ROOT / "content" / name).glob("*.md"))]
    return sorted(items, key=lambda i: str(i.meta.get("date", "")), reverse=True)


def inline_markup(text: str) -> str:
    escaped = html.escape(text.strip())
    escaped = re.sub(r"\*\*(.+?)\*\*", r"<strong>\1</strong>", escaped)
    escaped = re.sub(r"\*(.+?)\*", r"<em>\1</em>", escaped)
    escaped = re.sub(r"\[([^\]]+)\]\(([^)]+)\)", r'<a href="\2">\1</a>', escaped)
    return escaped


def markdown_to_html(markdown: str) -> str:
    blocks: list[str] = []
    paragraph: list[str] = []
    quote: list[str] = []
    list_items: list[str] = []

    def flush_paragraph() -> None:
        if paragraph:
            blocks.append(f"<p>{inline_markup(' '.join(paragraph))}</p>")
            paragraph.clear()

    def flush_quote() -> None:
        if quote:
            rendered = "".join(f"<p>{inline_markup(line)}</p>" for line in quote if line.strip())
            blocks.append(f"<blockquote>{rendered}</blockquote>")
            quote.clear()

    def flush_list() -> None:
        if list_items:
            blocks.append("<ul>" + "".join(f"<li>{inline_markup(item)}</li>" for item in list_items) + "</ul>")
            list_items.clear()

    for raw in markdown.splitlines() + [""]:
        line = raw.rstrip()
        if line.startswith(">"):
            flush_paragraph(); flush_list()
            quote.append(line[1:].strip())
            continue
        flush_quote()
        if line.startswith("### "):
            flush_paragraph(); flush_list()
            blocks.append(f"<h3>{inline_markup(line[4:])}</h3>")
        elif line.startswith("## "):
            flush_paragraph(); flush_list()
            blocks.append(f"<h2>{inline_markup(line[3:])}</h2>")
        elif line.startswith("# "):
            flush_paragraph(); flush_list()
            blocks.append(f"<h2>{inline_markup(line[2:])}</h2>")
        elif re.match(r"^[-*] ", line):
            flush_paragraph()
            list_items.append(line[2:].strip())
        elif not line.strip():
            flush_paragraph(); flush_list()
        else:
            paragraph.append(line.strip())
    return "\n".join(blocks)


def nav(active: str) -> str:
    items = [
        ("home", "/", "首页"),
        ("archive", "/archive/", "往期回顾"),
        ("committee", "/committee/", "组委会"),
        ("showcase", "/showcase/", "精彩展示"),
        ("news", "/news/", "News"),
        ("contact", "/contact/", "联系我们"),
    ]
    links = []
    for key, href, label in items:
        current = ' aria-current="page"' if key == active else ""
        links.append(f'<a href="{href}"{current}>{label}</a>')
    return "".join(links)


def header(site: dict[str, Any], active: str, solid: bool = False) -> str:
    solid_class = " header-solid" if solid else ""
    return f"""
<a class="skip-link" href="#main">跳到主要内容</a>
<header class="site-header{solid_class}" data-header>
  <div class="container header-inner">
    <a class="brand" href="/" aria-label="{html.escape(site['name'])}首页">
      <span class="brand-mark" aria-hidden="true">自</span>
      <span>
        <span class="brand-title">{html.escape(site['name'])}</span>
        <span class="brand-subtitle">Ziqiang Seminar</span>
      </span>
    </a>
    <nav class="desktop-nav" aria-label="主导航">{nav(active)}</nav>
    <button class="menu-button" data-menu-button aria-expanded="false" aria-controls="mobile-menu" aria-label="打开菜单"><span></span></button>
  </div>
  <div class="mobile-menu" id="mobile-menu" data-mobile-menu>
    <nav aria-label="移动端导航">{nav(active)}</nav>
    <p class="mobile-contact">联系邮箱：<a href="mailto:{html.escape(site['email'])}">{html.escape(site['email'])}</a></p>
  </div>
</header>
"""


def footer(site: dict[str, Any]) -> str:
    return f"""
<footer class="site-footer" id="contact-footer">
  <div class="container footer-main">
    <section>
      <a class="brand" href="/">
        <span class="brand-mark" aria-hidden="true">自</span>
        <span><span class="brand-title">{html.escape(site['name'])}</span><span class="brand-subtitle">Ziqiang Seminar</span></span>
      </a>
      <p class="footer-copy">面向高校师生的年度学术交流活动，以严谨求实为志业，致力于青年学者的成长与学术共同体的建设。</p>
      <a class="footer-email" href="mailto:{html.escape(site['email'])}">{html.escape(site['email'])}</a>
    </section>
    <section>
      <h2 class="footer-title">快速导航</h2>
      <nav class="footer-links" aria-label="页脚导航">
        <a href="/">首页</a><a href="/archive/">往期回顾</a><a href="/committee/">组委会</a>
        <a href="/showcase/">精彩展示</a><a href="/news/">News</a><a href="/contact/">联系我们</a>
      </nav>
    </section>
    <section>
      <h2 class="footer-title">学术刊物</h2>
      <a class="magazine-teaser" href="/magazine/">
        <strong>《自强》学刊</strong>
        <p>研讨会学术辑刊，收录年度入选论文与综述。</p>
        <span>敬请期待 ↗</span>
      </a>
    </section>
  </div>
  <div class="container footer-bottom">
    <span>{html.escape(site['copyright'])}</span>
    <div><a href="/contact/">联系组委会</a><a href="#top">回到顶部 ↑</a></div>
  </div>
</footer>
"""


def layout(site: dict[str, Any], title: str, description: str, body: str, active: str = "", solid: bool = True) -> str:
    full_title = title if site["name"] in title else f"{title} · {site['name']}"
    return f"""<!doctype html>
<html lang="zh-CN">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="description" content="{html.escape(description)}">
  <meta name="theme-color" content="#f9f8f6">
  <meta property="og:title" content="{html.escape(full_title)}">
  <meta property="og:description" content="{html.escape(description)}">
  <meta property="og:type" content="website">
  <title>{html.escape(full_title)}</title>
  <link rel="icon" href="/assets/images/favicon.svg" type="image/svg+xml">
  <link rel="stylesheet" href="/assets/css/site.css">
  <script defer src="/assets/js/app.js"></script>
</head>
<body id="top">
{header(site, active, solid)}
{body}
{footer(site)}
</body>
</html>
"""


def section_heading(en: str, zh: str, intro: str = "", center: bool = False) -> str:
    cls = "section-heading center" if center else "section-heading"
    intro_html = f'<p class="section-intro">{html.escape(intro)}</p>' if intro else ""
    eyebrow_cls = "eyebrow center" if center else "eyebrow"
    return f'<div class="{cls}"><div class="{eyebrow_cls}">{html.escape(en)}</div><h2>{html.escape(zh)}</h2>{intro_html}</div>'


def news_url(item: ContentItem) -> str:
    return f"/news/{item.meta['slug']}/"


def archive_url(item: ContentItem) -> str:
    return f"/archive/{item.meta['slug']}/"


def news_item_html(item: ContentItem) -> str:
    m = item.meta
    return f"""
<article class="news-item">
  <div><span class="news-date">{html.escape(str(m['date']).replace('-', '.'))}</span><span class="tag">{html.escape(str(m['category']))}</span></div>
  <div><a href="{news_url(item)}"><h3>{html.escape(str(m['title']))}</h3></a><p>{html.escape(str(m['description']))}</p><a class="read-more" href="{news_url(item)}">阅读全文 →</a></div>
</article>"""


def showcase_card(item: ContentItem) -> str:
    m = item.meta
    return f"""
<article class="showcase-card">
  <div class="showcase-card-head"><span class="file-icon" aria-hidden="true">文</span><span class="tag">{html.escape(str(m['type']))}</span></div>
  <h3>{html.escape(str(m['title']))}</h3>
  <div class="showcase-author">{html.escape(str(m['author']))} · {html.escape(str(m['identity']))}</div>
  <p>{html.escape(str(m['description']))}</p>
  <a class="showcase-download" href="{html.escape(str(m['file']))}" download>↓ 下载 PDF</a>
</article>"""


def render_home(site: dict[str, Any], news: list[ContentItem], showcases: list[ContentItem], programme: list[dict], sponsors: list[dict]) -> str:
    programme_html = "".join(
        f"""<article class="programme-card"><div class="programme-number">{p['number']}</div><h3>{html.escape(p['title'])}</h3><p>{html.escape(p['description'])}</p><div class="programme-meta"><strong>{html.escape(p['speaker'])}</strong><time>{html.escape(p['time'])}</time></div></article>"""
        for p in programme
    )
    programme_html += """<a class="programme-card programme-more" href="/archive/"><div class="programme-number">MORE</div><h3>查看更多环节</h3><p>完整日程、场地与报名通道详见本届活动手册。</p><div class="programme-meta"><strong>进入完整日程 →</strong></div></a>"""
    news_html = "".join(news_item_html(item) for item in news[:3])
    showcase_html = "".join(showcase_card(item) for item in showcases[:4])
    sponsor_html = "".join(f'<a href="{html.escape(s["url"])}" aria-label="{html.escape(s["name"])}">{html.escape(s["name"])}</a>' for s in sponsors)
    slogan_lines = html.escape(site["slogan"]).replace("\n", "<br>")
    body = f"""
<main id="main">
  <section class="hero">
    <div class="hero-media"><img src="/assets/images/library-hero.webp" alt="古典图书馆拱顶与阅览空间的黑白照片"></div>
    <div class="container hero-content">
      <div class="eyebrow">{html.escape(site['name_en'])} · {html.escape(site['edition'])}</div>
      <h1>{slogan_lines}</h1>
      <p class="hero-copy">{html.escape(site['description'])}</p>
      <div class="hero-actions"><a class="button" href="/archive/">了解本期活动 →</a><a class="button secondary" href="/archive/">查看往期内容</a></div>
    </div>
    <div class="hero-meta"><div class="container hero-meta-inner"><span>{html.escape(site['season'])}</span><span class="theme">{html.escape(site['theme'])}</span><span>{html.escape(site['organizer'])}</span></div></div>
  </section>

  <section class="section" aria-labelledby="programme-title">
    <div class="container">
      {section_heading('Seminar Programme', '活动环节预览', '本届研讨会以主旨演讲为始，经分论坛、圆桌讨论，至学生成果展示，循序推进。')}
      <div class="programme-carousel" data-carousel>
        <div class="programme-track" data-carousel-track>{programme_html}</div>
        <div class="carousel-controls"><button data-carousel-prev aria-label="上一项">←</button><button data-carousel-next aria-label="下一项">→</button></div>
      </div>
    </div>
  </section>

  <section class="section tint" id="news">
    <div class="container news-layout">
      <div>{section_heading('Latest News', '最新动态', '关注研讨会的征稿、评议与活动进展。')}<p><a class="text-link" href="/news/">查看全部新闻 →</a></p></div>
      <div class="news-list">{news_html}</div>
    </div>
  </section>

  <section class="section" id="showcase">
    <div class="container">
      <div class="section-topline">{section_heading('Student Showcase', '精彩展示', '历届研讨会入选的同学报告与项目材料，供查阅与下载。')}<a class="text-link" href="/showcase/">查看全部 →</a></div>
      <div class="showcase-grid">{showcase_html}</div>
    </div>
  </section>

  <section class="section tint">
    <div class="container">
      {section_heading('Partners & Sponsors', '赞助与合作方', '诚邀高校院系、学术机构与公益基金会共同支持自强学术研讨会。', True)}
      <div class="sponsor-grid">{sponsor_html}</div>
    </div>
  </section>
</main>
"""
    return layout(site, site["name"], site["description"], body, "home", False)


def render_page_hero(en: str, title: str, description: str) -> str:
    return f"""<section class="page-hero"><div class="container"><div class="eyebrow">{html.escape(en)}</div><h1 class="page-title">{html.escape(title)}</h1><p class="page-description">{html.escape(description)}</p></div></section>"""


def render_news_index(site: dict[str, Any], news: list[ContentItem]) -> str:
    items = "".join(news_item_html(i) for i in news)
    body = f"<main id='main'>{render_page_hero('News & Updates','新闻与预热','活动前发布预热、嘉宾和招募信息，活动后沉淀客观而具有学术信息量的新闻记录。')}<section class='section'><div class='container'><div class='news-list'>{items}</div></div></section></main>"
    return layout(site, "News", "自强学术研讨会新闻、预热与活动记录。", body, "news")


def render_archive_index(site: dict[str, Any], archive: list[ContentItem]) -> str:
    cards = "".join(f"""<a class="archive-card" href="{archive_url(i)}"><time>{html.escape(str(i.meta['date']))}</time><h3>{html.escape(str(i.meta['title']))}</h3><p>{html.escape(str(i.meta['description']))}</p><span class="text-link">查看回顾 →</span></a>""" for i in archive)
    body = f"<main id='main'>{render_page_hero('Past Seminars','往期回顾','按届次与日期沉淀历届活动新闻、推广内容与学术资料入口。')}<section class='section'><div class='container'><div class='cards-grid'>{cards}</div></div></section></main>"
    return layout(site, "往期回顾", "自强学术研讨会历届活动回顾与资料归档。", body, "archive")


def render_committee(site: dict[str, Any], members: list[dict]) -> str:
    cards = "".join(f"""<article class="member-card"><div class="member-avatar" aria-hidden="true">{html.escape(m['initial'])}</div><h3>{html.escape(m['name'])}</h3><div class="member-role">{html.escape(m['role'])}</div><p>{html.escape(m['bio'])}</p><a class="text-link" href="{html.escape(m['link'])}">个人链接（待补） →</a></article>""" for m in members)
    body = f"<main id='main'>{render_page_hero('Organizing Committee','组委会成员','展示组委会构成、职责与对外联系信息；人物照片和个人链接均可由内容组后续替换。')}<section class='section'><div class='container'><p class='notice'>当前成员姓名与头像为示例占位内容，上线前请由组委会统一审核并替换。</p><div class='cards-grid'>{cards}</div></div></section></main>"
    return layout(site, "组委会成员", "自强学术研讨会组委会成员与职责。", body, "committee")


def render_showcase(site: dict[str, Any], showcases: list[ContentItem]) -> str:
    cards = "".join(showcase_card(i) for i in showcases)
    body = f"<main id='main'>{render_page_hero('Student Showcase','精彩展示','以摘要卡片与资料下载链接展示同学报告、论文和项目，不在网页中嵌入完整 PPT。')}<section class='section'><div class='container'><div class='showcase-grid'>{cards}</div></div></section></main>"
    return layout(site, "精彩展示", "历届研讨会入选报告、论文和项目资料。", body, "showcase")


def render_contact(site: dict[str, Any]) -> str:
    body = f"""<main id="main">{render_page_hero('Contact Us','联系我们','统一的正式联系入口，分别承接参与分享与赞助合作两类诉求。')}
<section class="section"><div class="container"><div class="contact-grid">
  <article class="contact-card"><div class="eyebrow">Participate & Share</div><h2>参与与分享</h2><p>欢迎申请加入研讨会、提交报告提案、参与志愿工作或推荐值得关注的青年学者与项目。</p><div class="contact-meta"><strong>主要联系方式</strong><p><a href="mailto:{html.escape(site['email'])}">{html.escape(site['email'])}</a></p><p>对接人：相关负责人（待补）</p></div></article>
  <article class="contact-card"><div class="eyebrow">Sponsor & Collaborate</div><h2>赞助与合作</h2><p>欢迎高校院系、学术机构、企业与公益基金会就场地、物资、传播和长期合作进行正式沟通。</p><div class="contact-meta"><strong>合作联系方式</strong><p><a href="mailto:{html.escape(site['email'])}">{html.escape(site['email'])}</a></p><p>对接人：后勤/采购负责人（待补）</p></div></article>
</div><p class="notice" style="margin-top:2rem">需求书中的具体邮箱、手机号和对接人尚未最终确定；当前内容集中在 data/site.json 与本页模板中，便于统一替换。</p></div></section></main>"""
    return layout(site, "联系我们", "联系自强学术研讨会组委会，参与分享或洽谈赞助合作。", body, "contact")


def render_magazine(site: dict[str, Any]) -> str:
    body = f"<main id='main'>{render_page_hero('Magazine','《自强》学刊','用于完整故事、学术深度、人物志与会后采访的长期内容分区。')}<section class='section'><div class='container'><div class='empty-state'><div class='eyebrow center'>Coming Soon</div><h2>内容体系正在建设中</h2><p>首期不强制上线。路由和视觉入口已预留，后续可直接沿用现有文章模板扩展人物志、深度报道与年度学术辑刊。</p><a class='button accent' href='/news/'>先阅读 News</a></div></div></section></main>"
    return layout(site, "《自强》学刊", "自强学术研讨会学术杂志与深度内容分区。", body)


def render_article(site: dict[str, Any], item: ContentItem, active: str, base: str, prev_item: ContentItem | None, next_item: ContentItem | None) -> str:
    m = item.meta
    cover = m.get("cover", "/assets/images/library-article.webp")
    attachment = m.get("attachment")
    attachment_html = ""
    if attachment:
        attachment_html = f"""<aside class="download-box"><strong>{html.escape(str(m.get('attachment_label','相关资料（PDF）')))}</strong><p>静态文件下载入口；替换 public/assets/files 中的文件即可。</p><a class="button accent" href="{html.escape(str(attachment))}" download>↓ 下载 PDF</a></aside>"""
    prefix = "/news" if base == "news" else "/archive"
    def nav_link(label: str, target: ContentItem | None) -> str:
        if target is None:
            return "<span></span>"
        return f'<a href="{prefix}/{target.meta["slug"]}/"><small>{label}</small><strong>{html.escape(str(target.meta["title"]))}</strong></a>'
    breadcrumbs_label = "News" if base == "news" else "往期回顾"
    body = f"""
<main id="main">
  <nav class="breadcrumbs" aria-label="面包屑"><div class="container"><ol><li><a href="/">首页</a></li><li><a href="{prefix}/">{breadcrumbs_label}</a></li><li>{html.escape(str(m['category']))}</li></ol></div></nav>
  <article class="article-wrap">
    <header class="article-header">
      <div class="article-kicker"><span class="tag">{html.escape(str(m['category']))}</span></div>
      <h1 class="article-title">{html.escape(str(m['title']))}</h1>
      <p class="article-deck">{html.escape(str(m['description']))}</p>
      <div class="article-meta"><time>{html.escape(str(m['date']))}</time><span>作者 · {html.escape(str(m.get('author','组委会')))}</span><span>来源 · {html.escape(str(m.get('source',site['name'])))}</span></div>
    </header>
    <figure class="article-cover"><img src="{html.escape(str(cover))}" alt="古典图书馆内部的黑白照片"><figcaption>图 · 本站示例视觉素材；正式上线前请核对图片版权与来源。</figcaption></figure>
    <div class="article-body">{markdown_to_html(item.body)}</div>
    {attachment_html}
  </article>
  <nav class="article-nav" aria-label="文章导航"><div class="container article-nav-inner">{nav_link('上一篇', prev_item)}{nav_link('下一篇', next_item)}</div></nav>
</main>
"""
    return layout(site, str(m["title"]), str(m["description"]), body, active)


def favicon_svg() -> str:
    return """<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64"><rect width="64" height="64" fill="#f9f8f6"/><rect x="10" y="10" width="44" height="44" fill="none" stroke="#1a1a1a" stroke-width="2"/><text x="32" y="42" text-anchor="middle" font-family="serif" font-size="30" font-weight="700" fill="#1a1a1a">自</text></svg>"""


def write_page(path: str, content: str) -> None:
    destination = DIST / path
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text(content, encoding="utf-8")


def main() -> None:
    site = load_json("site.json")
    programme = load_json("programme.json")
    members = load_json("members.json")
    sponsors = load_json("sponsors.json")
    news = load_collection("news")
    archive = load_collection("archive")
    showcases = load_collection("showcase")

    if DIST.exists():
        shutil.rmtree(DIST)
    (DIST / "assets").mkdir(parents=True)
    shutil.copytree(ROOT / "src" / "assets", DIST / "assets", dirs_exist_ok=True)
    (DIST / "assets" / "images" / "favicon.svg").write_text(favicon_svg(), encoding="utf-8")

    write_page("index.html", render_home(site, news, showcases, programme, sponsors))
    write_page("news/index.html", render_news_index(site, news))
    write_page("archive/index.html", render_archive_index(site, archive))
    write_page("committee/index.html", render_committee(site, members))
    write_page("showcase/index.html", render_showcase(site, showcases))
    write_page("contact/index.html", render_contact(site))
    write_page("magazine/index.html", render_magazine(site))

    for index, item in enumerate(news):
        prev_item = news[index - 1] if index > 0 else None
        next_item = news[index + 1] if index + 1 < len(news) else None
        write_page(f"news/{item.meta['slug']}/index.html", render_article(site, item, "news", "news", prev_item, next_item))
    for index, item in enumerate(archive):
        prev_item = archive[index - 1] if index > 0 else None
        next_item = archive[index + 1] if index + 1 < len(archive) else None
        write_page(f"archive/{item.meta['slug']}/index.html", render_article(site, item, "archive", "archive", prev_item, next_item))

    (DIST / "robots.txt").write_text("User-agent: *\nAllow: /\n", encoding="utf-8")
    (DIST / "404.html").write_text(layout(site, "页面未找到", "请求的页面不存在。", "<main id='main'><section class='page-hero'><div class='container'><div class='eyebrow'>404</div><h1 class='page-title'>页面未找到</h1><p class='page-description'>链接可能已改变，或内容尚未发布。</p><p><a class='button accent' href='/'>返回首页</a></p></div></section></main>"), encoding="utf-8")
    print(f"Built {sum(1 for p in DIST.rglob('*.html'))} HTML pages into {DIST}")


if __name__ == "__main__":
    main()
